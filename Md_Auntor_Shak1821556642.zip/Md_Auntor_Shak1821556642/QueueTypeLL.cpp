#ifndef QUEUETYPELL_CPP
#define QUEUETYPELL_CPP
#include "QueueTypeLL.h"

template<class ItemType>
QueueTypeLL<ItemType>::QueueTypeLL()
{

    frnt=NULL;
    rear=NULL;
}

template<class ItemType>
QueueTypeLL<ItemType>::~QueueTypeLL()
{
    makeEmpty();
}

template<class ItemType>
void QueueTypeLL<ItemType>::makeEmpty()
{
    NodeType<ItemType> *temp;
    while(frnt)
    {
        temp=frnt;
        frnt=frnt->next;
        delete temp;
    }
}

template<class ItemType>
void QueueTypeLL<ItemType>::Enqueue(ItemType item)
{
    NodeType<ItemType> *temp = new NodeType<ItemType>;
    temp->data = item;
    temp->next = NULL;
    if(frnt==NULL){frnt=temp;rear=temp;}
    else
    {rear->next = temp;
    rear=temp;}
}

template<class ItemType>
void QueueTypeLL<ItemType>::Dequeue()
{
    if(frnt==rear)
    { frnt==NULL; rear=NULL;}
    else
    {
    NodeType<ItemType> *temp;
    temp = frnt;
    frnt = frnt->next;
    delete temp;
    }
}

template<class ItemType>
void QueueTypeLL<ItemType>::printQueue() const
{

    NodeType<ItemType> *temp = frnt;
    while(temp)
    {
        cout<<temp->data<<" ";
        temp = temp->next;
    }
cout<<endl;
}

template<class ItemType>
bool QueueTypeLL<ItemType>::isEmpty() const
{
    return (frnt==NULL);
}

template<class ItemType>
bool QueueTypeLL<ItemType>::isFull() const
{
    NodeType<ItemType> *temp;

    try
    {
        temp = new NodeType<ItemType>;
        delete temp;
        return false;
    }
    catch(bad_alloc e){
    return true;
    }

    return (frnt==NULL);
}

#endif // QUEUETYPELL_H

