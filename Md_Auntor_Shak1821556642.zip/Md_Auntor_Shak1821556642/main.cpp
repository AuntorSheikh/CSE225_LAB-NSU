#include <iostream>
#include"QueueTypeLL.cpp"

using namespace std;

int main()
{

    QueueTypeLL<int> q;
    if(q.isEmpty())
    cout<<"Queue is Empty"<<endl;
    else
    cout<<"Queue is not Empty"<<endl;

    q.Enqueue(5);
    q.Enqueue(7);
    q.Enqueue(4);
    q.Enqueue(2);

    if(q.isEmpty())
    cout<<"Queue is Empty"<<endl;
    else
    cout<<"Queue is not Empty"<<endl;

    if(q.isFull())
    cout<<"Queue is Full"<<endl;
    else
    cout<<"Queue is not Full"<<endl;

    q.Enqueue(6);
    q.printQueue();
     if(q.isFull())
    cout<<"Queue is Full"<<endl;

    else
    cout<<"Queue is not Full"<<endl;
    q.Dequeue();
    q.Dequeue();
    q.printQueue();

    return 0;
}
