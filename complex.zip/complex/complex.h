#ifndef COMPLEX_H_INCLUDED
#define COMPLEX_H_INCLUDED

class Complex
{
    friend Complex operator+(int ,Complex &);
    friend Complex operator+(Complex &, int);
public:

    Complex();
    Complex(int,int);
    Complex operator+(Complex &);
    void print();



private:
    int Real, Imaginary;
};

#endif // COMPLEX_H_INCLUDED

