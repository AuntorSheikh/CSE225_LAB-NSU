#include "complex.h"
#include <iostream>
using namespace std;
Complex::Complex()
{
    Real = 0;
    Imaginary = 0 ;
}
Complex::Complex(int r, int i)
{
    Real = r;
    Imaginary = i;
}

Complex Complex::operator+(Complex &a)
{
    Complex t;
    t.Real = Real+a.Real;
    t.Imaginary = Imaginary+ a.Imaginary;
    return t;
}
Complex operator+(int a,Complex &b)
{
    Complex t;
    t.Real = a+b.Real;
    t.Imaginary = 0+b.Imaginary;
    return t;
}
Complex operator+(Complex &a, int b)
{
    Complex t;
    t.Real = a.Real+ b;
    t.Imaginary = a.Imaginary;
    return t;
}
void Complex::print()
{
    cout<<Real<<"+"<<Imaginary<<"i"<<endl;
}

