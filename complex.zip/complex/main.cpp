#include <iostream>
#include"complex.h"
using namespace std;

int main()
{

    Complex c1(1,2);
    Complex c2(3,4);
    Complex sum;
    sum = c1+3;
    sum.print();
    return 0;
}
