#include <iostream>
#include "binarysearchtree.cpp"
using namespace std;

void BinarySearch(int arr[], int first,
                  int last)
{
    if(first<=last)
    {
        int midpoint=(last+first)/2;
        cout<<endl;
        cout<<midpoint<<" point ";
        cout<<arr[midpoint]<<" ";
        BinarySearch(arr,first,midpoint-1);
        BinarySearch(arr, midpoint+1,last);
    }

}

int main(){
    TreeType<int> q;

    if(q.IsEmpty()){
        cout << "Tree is Empty" << endl;
    }else{
        cout << "Tree is not Empty" << endl;
    }

    q.InsertItem(4);
    q.InsertItem(9);
    q.InsertItem(2);
    q.InsertItem(7);
    q.InsertItem(3);
    q.InsertItem(11);
    q.InsertItem(17);
    q.InsertItem(0);
    q.InsertItem(5);
    q.InsertItem(1);

    if(q.IsEmpty()){
        cout << "Tree is Empty" << endl;
    }else{
        cout << "Tree is not Empty" << endl;
    }

    cout << "Tree Length: " << q.LengthIs() << endl;

    int item = 9;
    bool found;
    q.RetrieveItem(item, found);
    if(!found){
        cout << "Item 9 not Found" << endl;
    }else{
        cout << "Item 9 Found" << endl;
    }

    item = 13;
    q.RetrieveItem(item, found);
    if(!found){
        cout << "Item 13 not Found" << endl;
    }else{
        cout << "Item 13 Found" << endl;
    }

    q.Print();
    cout << endl;

    int counter;
    q.ResetTree(PRE_ORDER);
    for(counter = 0; counter < q.LengthIs(); counter++){
        q.GetNextItem(item, PRE_ORDER, found);
        cout << item << " ";
    }

    cout << endl;
    q.ResetTree(POST_ORDER);
    for(counter = 0; counter < q.LengthIs(); counter++){
        q.GetNextItem(item, POST_ORDER, found);
        cout << item << " ";
    }

    q.MakeEmpty();
    cout<<endl;

     TreeType <int> bt;
    int bb;
    int arr[10];
    cout<<"enter the values: "<<endl;
    for(int i=0;i<10;i++){
        cin>>bb;
       bt.InsertItem(bb);
    }
    bt.ResetTree(IN_ORDER);

    cout<<"The items in order is: "<<endl;
    int xx;
    bool finished;
    for(int i=0;i<10;i++){

        bt.GetNextItem(xx, IN_ORDER, finished);
        cout<<xx<<" ";
        arr[i]=xx;

    }
    cout<<endl<<endl;
    cout<<"Best order sequence is: "<<endl;
    BinarySearch(arr,0,9);
    return 0;
}
