#include <iostream>
#include"stacktype.cpp"
using namespace std;
void Print(stacktype <int> s1)
{   stacktype<int>aux;
    while(!s1.IsEmpty())
    {
        aux.Push(s1.Top());
        s1.Pop();
    }
    while(!aux.IsEmpty())
    {
        s1.Push(aux.Top());
        cout<<aux.Top()<<"   ";
        aux.Pop();
    }
    cout<<endl;
}
int main()
{
    stacktype<int> s1;
    stacktype<int> aux;
    s1.Push(5);
    s1.Push(4);
    s1.Push(7);
    s1.Push(1);
    Print(s1);
    return 0;
}
