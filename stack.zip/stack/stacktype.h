#ifndef STACKTYPE_H_INCLUDED
#define STACKTYPE_H_INCLUDED
const int max_items =5;
template <class T>
class  stacktype
{
public:
    stacktype();
    bool IsFull();
    bool IsEmpty();
    void Push(T);
    void Pop();
    T Top();
private:
    int top;
    T info[max_items];
};
#endif // STACKTYPE_H_INCLUDED
