#include <iostream>
#include<bits/stdc++.h>
#include<cmath>
using namespace std;
//Factorial
int fact(int n)
{
if (n>1)
return n*fact(n-1);
}
//Fibonacci
int fib(int n)
{
if((n==1)||(n==0))
{
return (n);
}
else
{
return(fib(n-1)+fib(n-2));
}
}
//Sum_of_digit
int sum_of_digit(int n)
{
if(n==0)
return 0;
return (n%10+sum_of_digit(n/10));
}
//Find Minimum
int findMin(int A[],int n)
{
if(n==1)
return A[0];
return min(A[n-1],findMin(A, n-1));
}
//Decimal to Binary convert
int Dec_to_Binary(int decimal_number)
{
if(decimal_number==0)
return 0;
else
return (decimal_number%2+10*Dec_to_Binary(decimal_number/2));
}
//Series Sum
 double Ssum(int n)
{
if(n==0)
{
return 1;
}
else
{
double a= pow(2,n);
 a=(1/a) + (Ssum(n-1));
return a;
}
}

int main()
{
    cout<<endl;
    int n,i=0;
    cout<<"Enter the term of Series: ";
    cin>>n;
    cout<<"\nFibonacci Series: ";
    while(i<n){
    cout<<" " <<fib(i);
    i++;
    }

    int N=5;
    cout<<"Factorial :"<< fact(N)<<"\n";


    cout<<endl;
    int num=123456789;
    int result=sum_of_digit(num);
    cout<<"sum_of_digit in "<< num <<" is "<<result<<endl;

    cout<<endl;
    int A[]={1,2,50,70,90,-100,10,3};

    n=sizeof(A)/sizeof(A[0]);
    cout<<"FindMinimum: "<<findMin(A, n);

    cout<<endl;
    int decimal_number=10;
    cout<<"Decimal to Binary: "<<Dec_to_Binary(decimal_number);

    cout<<endl;
    cout<<"Summation up till which term: ";
    int a;
    cin>>a;
    cout<<"Series Sum: "<<Ssum(a);

    return 0;
}
