#include <iostream>
#include"Stacklinklist.cpp"
using namespace std;
int main() {
	Stack<int> stack;
	stack.PrintStackData();
	stack.Push(5);
	stack.Push(7);
	stack.Push(4);
	stack.Push(2);
	stack.IsEmpty();
	stack.IsFull();

    Stack<int> stack2;
    stack2.Push(stack.Pop());
    stack2.Push(stack.Pop());
    stack2.Push(stack.Pop());
    stack2.Push(stack.Pop());
	cout << "Current Stack: ";
	stack2.PrintStackData();

	Stack<int> stack3;
	stack3.Push(stack2.Pop());
	stack3.Push(stack2.Pop());
	stack3.Push(stack2.Pop());
	stack3.Push(stack2.Pop());
	stack3.Push(3);

	Stack<int> stack4;
	stack4.Push(stack3.Pop());
	stack4.Push(stack3.Pop());
	stack4.Push(stack3.Pop());
	stack4.Push(stack3.Pop());
	stack4.Push(stack3.Pop());
	cout << "Current Stack: ";
	stack4.PrintStackData();
    stack4.IsFull();

	cout << "Now popping: "<< endl;
	stack4.Pop();
	stack4.Pop();
	cout << "Current Stack: ";
	stack4.PrintStackData();
    stack4.Top();


    stack3.BiggestVal();




	return 0;
}
