#include <iostream>
#include"Stacklinklist.h"
using namespace std;
template<class T>

Stack<T>::Stack() : headNode(0), size(0)
{ }

template<class T>
Stack<T>::Stack(T firstNodeData)
{
	headNode = new Node<T>(firstNodeData);
	headNode->SetNextNode(0);
	size = 1;
}

template<class T>
Stack<T>::~Stack()
{
	MakeEmpty();
}

template<class T>
void Stack<T>::Push(T data)
{
	auto newNode = new Node<T>(data);

	if (size == 0) {
		headNode = newNode;
		headNode->SetNextNode(0);
	}
	else {
		newNode->SetNextNode(headNode);
		headNode = newNode;
	}
	size++;
}

template<class T>
T Stack<T>::Pop()
{
	if (size == 0)
	{
	    cout << "The stack is empty." << endl;
		return 0;
	}

	else {
		T data = headNode->GetNodeData();
		auto temp = headNode;
		headNode = headNode->GetNextNode();
		temp->SetNextNode(0);
		delete temp;
		size--;
		return data;
	}
}

template<class T>
void Stack<T>::PrintStackData()
{
	if (size == 0) {
		cout << "The stack is empty." << endl;
		return;
	}
	Node<T>* temp = headNode;
	for(int i = 0; i < size; i++){
		cout << temp->GetNodeData() << ", ";
		temp = temp->GetNextNode();
	}
	cout << "\n";
}

template<class T>
int Stack<T>::GetSize()
{
	return size;
}

template<class T>
void Stack<T>::MakeEmpty()
{
	while (size > 0) {
		Pop();
	}
	delete headNode;
}
template<class T>
bool Stack<T>::IsFull()
{

	if (size == maxsize) {
		cout << "The stack is Full" << endl;
		return 0;
	}
	else
	{
	cout<<"The stack Is not Full"<<endl;
	return 0 ;
	}

 }
template<class T>
bool Stack<T>::IsEmpty()
{

	if (size < 0) {
		cout << "The stack Is Empty" << endl;
		return 0;
	}
	else
	{
	cout<<"The stack Is not Empty"<<endl;
	return 0 ;
	}

 }
 template<class T>
 T Stack<T>::Top()
  {

       if (headNode)
          cout<<"Top: "<< headNode->data;

       else
         cout << "Stack is empty" << endl;
  }

  template<class T>
  bool Stack<T>::BiggestVal()
  {
  int max;
    while (headNode != NULL) {
        if (max < headNode->data)
            max = headNode->data;
        headNode = headNode->GetNextNode();
    }
    return max;
  }

