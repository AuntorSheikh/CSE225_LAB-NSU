#ifndef STACKLINKEDLIST_H_INCLUDED
#define STACKLINKEDLIST_H_INCLUDED
template <class T>
class Node {
private:

	Node<T>* nextNode;
public:
    T data;
	Node(T input);
	T GetNodeData();
	Node<T>* GetNextNode();
	void SetNextNode(Node<T>* nextNode);
};

template<class T>
Node<T>::Node(T input) : data(input)
{
	nextNode = nullptr;
}

template<class T>
T Node<T>::GetNodeData()
{
	return data;
}

template<class T>
Node<T>* Node<T>::GetNextNode()
{
	return nextNode;
}

template<class T>
void Node<T>::SetNextNode(Node<T>* node)
{
	nextNode = node;
}

template <class T>
class Stack {
private:
	Node<T>* headNode;
	int size;
	int maxsize=5;
public:
	Stack();
	Stack(T firstNodeData);
	~Stack();
	void Push(T data);
	T Pop();
	void PrintStackData();
	int GetSize();
	void MakeEmpty();
	bool IsFull();
	bool IsEmpty();
	T Top();
	bool BiggestVal();
};


#endif // STACKTYPELINKEDLIST_H_INCLUDED
