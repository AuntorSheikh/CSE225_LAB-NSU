#include"stacktype.h"

template<class T>
stacktype<T>::stacktype()
{
    top=-1;
}
template<class T>
bool stacktype<T>::IsFull()
{
     return top==max_items-1;
}
template<class T>
bool stacktype<T>::IsEmpty()
{
   if(top == -1){
   return true;
   }
   else
   return false;
}

template<class T>
void stacktype<T>::Push(T item)
{
    top++;
    info[top] = item;
}

template<class T>
void stacktype<T>::Pop()
{
    top--;
}

template<class T>
T stacktype<T>::Top()
{
    return info[top];
}



