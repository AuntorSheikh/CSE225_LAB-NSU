#include"quetype.h"
template<class T>
QueType<T>::QueType()
{
front=-1;
rear=-1;
maxQue=501;
info=new T[maxQue];
}

template<class T>
QueType<T>::QueType(int max){
   front=-1;
rear=-1;
maxQue=max;
info=new T[maxQue];
}
template<class T>
QueType<T>::~QueType(){
    delete [] info;
}
template<class T>
void QueType<T>::MakeEmpty()
{
 return rear=-1;
}
template<class T>
bool QueType<T>:: IsFull(){
    return rear == info-1;
}
template<class T>
bool QueType<T>::IsEmpty(){
   return rear == -1;
}
template<class T>
void QueType<T>::Enqueue(T item){

    info[++rear] = item;
}
template<class T>
void QueType<T>::Dequeue(){

    for(int i=1;i<=rear;i++){
        info[i-1] = info[i];
    }
    rear--;
}
template<class T>
T QueType<T>::Front()
{
return info[front];
}
template<class T>
void QueType<T>::printQue(){
    for(int i=0;i<=rear;i++){
        info[i];
    }
}
