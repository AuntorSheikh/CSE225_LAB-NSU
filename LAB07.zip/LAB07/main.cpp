#include"quetype.cpp"
#include <iostream>

using namespace std;

int main()
{
    // create a queue of capacity 4
	QueType<string> q(4);

	q.Enqueue("a");
	q.Enqueue("b");
	q.Enqueue("c");

	cout << "Front element is: " << q.Front() << endl;
	q.Dequeue();

	q.Enqueue("d");


	q.Dequeue();
	q.Dequeue();
	q.Dequeue();

	if (q.IsEmpty())
		cout << "Queue Is Empty\n";
	else
		cout << "Queue Is Not Empty\n";

	return 0;
}
