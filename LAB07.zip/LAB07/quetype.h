#ifndef QUETYPE_H_INCLUDED
#define QUETYPE_H_INCLUDED

template<class T>
class QueType
{
public:
    QueType();
    QueType(int);
    ~QueType();
    void MakeEmpty();
    bool IsEmpty();
    bool IsFull();
    void Enqueue(T);
    void Dequeue();
    T Front();
    void printQue();
private:
    int front;
    int rear;
    T *info;
    int maxQue;
};
#endif // QUETYPE_H_INCLUDED
