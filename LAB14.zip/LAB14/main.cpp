#include <iostream>
#include "PQType.cpp"
#include "HeapType.h"
using namespace std;

int main()
{
    PQType<int> pq(15);

    if(pq.IsEmpty())
        cout << "Queue is empty." << endl;
    else
        cout << "Queue is not empty." << endl;

        cout<<"Input :"<<endl;
    int x;
    for(int i=0; i<10; i++)
    {
        cin >> x;
        pq.Enqueue(x);
    }

    if(pq.IsEmpty())
        cout << "Queue is empty." << endl;
    else
        cout << "Queue is not empty." << endl;

    pq.Dequeue(x);
    cout << x << endl;

    pq.Dequeue(x);
    cout << x << endl;

   cout<<"Input :"<<endl;
    PQType <int> candy(15);
    int NumberOfBag,min, SumOfCandies =0;

    cin >> NumberOfBag;
    cin >> min;

    for(int i=0;i<NumberOfBag; i++)
    {
        cin >> x;
        candy.Enqueue(x);
    }

    for(int i=0;i<min;i++)
    {
        candy.Dequeue(x);
        SumOfCandies = SumOfCandies+ x;
        x = x / 2;
        candy.Enqueue(x);
    }

    cout <<"SumOfCandies: "<< SumOfCandies << endl;

    return 0;
}
