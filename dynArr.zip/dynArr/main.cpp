#include <iostream>
#include "dynArr.h"
using namespace std;
int main()
{
dynArr d1(2,2);
d1.setValue(0,0,3);
d1.setValue(0,1,4);
d1.setValue(1,0,5);
d1.setValue(1,1,6);

cout<<d1.getValue(0,0)<<endl;
cout<<d1.getValue(0,1)<<endl;
cout<<d1.getValue(1,0)<<endl;
cout<<d1.getValue(1,1)<<endl;
return 0;
}
