#include "dynArr.h"
#include <iostream>
using namespace std;
dynArr::dynArr(){
arr=NULL;
row=0;
col=0;
}

dynArr::dynArr(int r,int c){
arr = new int*[r];
for(int i=0;i<r;i++){
arr[i]=new int [c];
}
row=r;
col=c;
}

dynArr::~dynArr(){
for(int i=0;i<row;i++){
 delete[] arr[row];
}
delete[]arr;
}

int dynArr::getValue(int r,int s){
return arr[r][s];
}

void dynArr::setValue(int r,int s,int value){
arr[r][s]=value;
}
int r,s;
void dynArr::print()
{
cout<<arr[r][s]<<endl;
}
